package com.example.ufit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
