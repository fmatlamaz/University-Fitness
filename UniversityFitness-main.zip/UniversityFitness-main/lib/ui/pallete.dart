import 'package:flutter/material.dart';

class FvColors {
  static const Color black = Color(0xFF000000);
}
