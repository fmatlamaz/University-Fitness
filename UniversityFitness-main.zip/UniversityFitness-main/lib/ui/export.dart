export 'components/button/buttonnext_button_22.dart';
export 'components/button/rectangle_button_66.dart';
export 'components/button/signuptabs_button_74.dart';
export 'components/button/rectangle_button_89.dart';
export 'pallete.dart';
export 'package:ufit/welcomePage_screen_1.dart';